COASTAL HIGHWAY - Mobile racing game prototype

Game:
- Portrait mobile layout using the coastal city background
- Three lanes; tap left/right to change lanes
- Avoid traffic cars
- Collect cash and lightning nitro pickups
- Nitro boost button, score, cash counter, and saved best score

FILES:
- index.html: browser-playable version
- www/: Cordova app web assets
- background.png: original coastal city background
- config.xml / package.json: Android wrapper configuration
- .github/workflows/build-android.yml: cloud APK build workflow

BUILD AN APK USING GITHUB (can be done from a phone):
1. Create a new GitHub repository.
2. Upload all files and folders from this ZIP to the repository root (including the hidden .github folder).
3. Open the repository's Actions tab.
4. Select "Build Android APK" and tap "Run workflow". Or push to the main branch to trigger it.
5. When the workflow completes, open its run page, scroll to Artifacts, and download "Coastal-Highway-APK".
6. Extract the downloaded artifact ZIP and install app-debug.apk on your Android phone. If Android asks, allow installing apps from that source.

This is a debug APK built by GitHub Actions, not a Play Store-signed release. The source package itself is not an APK; GitHub Actions compiles it in the cloud.
